// Loops

['a', 'b', 'c'].forEach(function(item, index, array) {
    console.log(item, index, array);
});

// for(let i = 0; i <= 100; i++) {
//     console.log('i', i)
// }

let a = 0;
while(a < 10) {
    console.log(a);
    a++;
}