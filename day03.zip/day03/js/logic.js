// Logic
let myName = 'Vinson'

if (myName === 'Vinson') {
    console.log('yes it is')
} else {
    console.log('no it is not')
}

myName === 'Vinson' ? console.log('yes it is 2') : console.log('no it is not 2')