// arithmetic

// addition
5 + 5;
// subtraction
5 - 1;
// multiplication
5 * 2;
// division
10 / 2;
// remainder (modulo, modulus)
20 % 9; // 2
// math plus assignment
let x = 5;
x += 5;
x *= 2;
x /= 4;



//  comparitive 
5 < 7; // true
5 >= 2; // true
5 === x; // true
5 !== x; // false;

// 
typeof 5; // number;
typeof x; // number;




