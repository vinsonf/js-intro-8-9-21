let myName = 'Vinson Fernandez';




let test = myName.split(' ');
console.log(myName.replace(' ', '').length);
console.log(test.splice(1, 1, 'Yeah!').join(' '));

console.log(test.join(' '))
console.log(myName.indexOf('son'));
console.log(myName.slice(7, 11));
console.log(myName.toUpperCase())
console.log(myName.toLowerCase())
console.log(myName.replace('son', 'dad'))


