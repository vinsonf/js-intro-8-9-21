// Global objects
// console.log(document);
// Math
// console.log(Math);
// const number = Math.random() * 20;
// console.log(number);
// console.log(Math.floor(number));
// console.log(Math.round(number));
// console.log(Math.ceil(number));

// Date
// const myDate = new Date();
// console.log(myDate.setDate(myDate.getDate() + 3));

// console.log(myDate);


