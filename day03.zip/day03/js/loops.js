// for(let i = 0; i < 100; i++) {
//     console.log('i', i);
//     const li = document.createElement('li');
//     li.innerText = 'I am a created li ' + i;
//     document.body.appendChild(li);
// }
// let m = 0;
// while( m < 100) {
//     console.log('m', m);
//     m++;
// }