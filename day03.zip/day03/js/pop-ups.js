// alert
let answer;
// anwer = alert('This is an Important message'); // no value

// confirm
// answer = confirm('Are you sure?'); // true or false
// prompt
// answer = prompt('what is your name?'); // string; or null;
